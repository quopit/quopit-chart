# Quopit Helm Chart

Quopit is an open-source no-code database tool and Airtable alternative. It is a modern database tool that allows you to create a database, web-based application, and API without code. It is built on top of Django and Vue.js and is designed to be easily deployed to a platform like Kubernetes.

This chart can have dependencies on other charts, such as PostgreSQL, Redis, Minio, and Caddy. The chart can be configured to use an existing instance of these services or deploy them as part of the Quopit deployment.

## Installing the Chart

To install the chart with the release name `my-quopit` run the following commands:

From repo
```bash
helm repo add quopit-chart https://baserow.github.io/baserow-chart
helm install my-quopit quopit-chart/quopit --namespace quopit --create-namespace --values config.yaml
```

From source code
```bash
helm dependency update
helm install my-quopit . --namespace quopit --create-namespace
helm upgrade my-quopit . --namespace quopit
```

## Minimal configuration

Make the following changes to the values file to deploy the Quopit application with the default configuration.

```yaml
global:
  quopit:
    domain: "your-quopit-domain.com"
    backendDomain: "api.your-quopit-domain.com"
    objectsDomain: "objects.your-quopit-domain.com"
```

## Using existing Postgres and Redis

You can use the following configuration to use an existing Postgres database and Redis cluster.

```yaml
redis:
  enabled: false

postgresql:
  enabled: false
```

Add the following configuration to the backendSecrets to use an existing managed database and Redis cluster. 
```yaml
backendSecrets:
  DATABASE_HOST: "my-quopit-quopit-backend-postgresql"
  DATABASE_PORT: "5432"
  DATABASE_NAME: "quopit"
  DATABASE_USER: "quopit"
  DATABASE_PASSWORD: "password"
  REDIS_HOST: "my-quopit-quopit-backend-redis"
  REDIS_PORT: "6379"
  REDIS_PASSWORD: "password"
```

## Caddy Ingress Configuration

Caddy is a web server that can be used as an ingress controller. When using Caddy, set the ingress configuration to use Caddy as the ingress controller. Make note of the `onDemandAsk` configuration, which is used to trigger on-demand TLS certificates. Pointed here to the health check endpoint of caddy itself to always create new certificates. On production workloads set it to the backend api endpoint to check if the domain exists in the database.

```yaml
caddy:
  enabled: true
  ingressController:
    className: caddy
    config:
      email: "my@email.com"
      proxyProtocol: true
      experimentalSmartSort: false
      onDemandTLS: true
      onDemandAsk: http://:9765/healthz
```

## Autoscaling configuration
For each Quopit component, a HorizontalPodAutoscaler can be configured individually. The following example enables autoscaling on the wsgi backend deployment.

```yaml
quopit-backend-wsgi:
  autoscaling:
    enabled: true
    minReplicas: 2
    maxReplicas: 10 
    targetCPUUtilizationPercentage: 80
    targetMemoryUtilizationPercentage: 80
```

```yaml
      onDemandAsk: "http://my-quopit-quopit-backend-wsgi/api/builder/domains/ask-public-domain-exists/"
```

## AI and Embeddings Configuration

Quopit supports multiple AI providers for generative AI features and the AI assistant. The embeddings service powers semantic search for the AI assistant's documentation lookup feature. For more documentation check the [Quopit AI documentation](/docs/installation/ai-assistant.md).

### Enable AI Assistant

To enable the AI assistant, you need to configure the LLM model and provide the necessary API keys for the chosen provider.

```yaml
global:
  quopit:
    assistantLLMModel: "groq/openai/gpt-oss-120b"

backendSecrets:
  GROQ_API_KEY: "your-groq-api-key"
```

More information about the available providers can be found here: https://github.com/quopit/quopit/blob/main/docs/installation/ai-assistant.md

### Enable Embeddings Service

The AI assistant uses the embeddings service and requires the LLM model to be configured. You need to enable this next to the global ai configuration.

#### Basic Configuration

```yaml
quopit-embeddings:
  enabled: true
```

## Different Cloud Providers

On different cloud providers, you may need to configure the Object storage, ingress and Load Balancer differently. Below are some examples of how to configure them.

### AWS

#### S3 Config
When deploying to AWS, you can use the following configuration to use S3 for object storage. Make sure to disable minio as it is not needed.

```yaml
minio:
  enabled: false

backendConfigMap:
  AWS_STORAGE_BUCKET_NAME: "my-quopit-quopit-backend-bucket"
  AWS_S3_CUSTOM_DOMAIN: "my-quopit-quopit-backend-bucket"
  AWS_S3_REGION_NAME: "us-east-1"
  AWS_S3_ENDPOINT_URL: "https://s3.us-east-1.amazonaws.com/my-quopit-quopit-backend-bucket"
```

#### AWS Authentication
AWS authentication can be set by service account or environment variables. Below is an example of setting the AWS credentials using the environment variables. 

```yaml
backendSecrets:
  AWS_ACCESS_KEY_ID: "my-access-key"
  AWS_SECRET_ACCESS_KEY: "my-secret-key"
```

When running on EKS you can also use a service account with an IAM role and permissions. For the service account, you can use the following configuration. To create the corresponding IAM role, refer to the AWS documentation. https://docs.aws.amazon.com/eks/latest/userguide/iam-roles-for-service-accounts.html

```yaml
global:
  quopit:
    serviceAccount:
      shared: true
      create: true
      name: quopit
      annotations: {}
```

#### Ingress

When deploying to AWS, you can use the following configuration to create a Network Load Balancer. For more information about the annotations, refer to the AWS documentation. https://docs.aws.amazon.com/eks/latest/userguide/network-load-balancing.html

```yaml
ingress:
  enabled: true

caddy:
  enabled: true
  ingressController:
    className: caddy
    config:
      email: "my@email.com"
      proxyProtocol: true
      experimentalSmartSort: false
      onDemandTLS: true
      onDemandAsk: http://:9765/healthz
  loadBalancer:
    externalTrafficPolicy: "Local"
    annotations:
      service.beta.kubernetes.io/aws-load-balancer-proxy-protocol: "*"
      service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"
      service.beta.kubernetes.io/aws-load-balancer-nlb-target-type: "ip"
      service.beta.kubernetes.io/aws-load-balancer-healthcheck-protocol: "TCP"
      service.beta.kubernetes.io/aws-load-balancer-alpn-policy: "HTTP2Preferred"
```

### Digital ocean

#### Ingress

When deploying to Digital Ocean, you can use the following configuration to create a Load Balancer. For more information about the annotations, refer to the Digital Ocean documentation. https://docs.digitalocean.com/products/kubernetes/how-to/add-load-balancers/

```yaml
ingress:
  enabled: true

caddy:
  enabled: true
  ingressController:
    config:
      email: "my@email.com"
      proxyProtocol: true
      experimentalSmartSort: false
      onDemandTLS: true
      onDemandRateLimitInterval: "2m"
      onDemandRateLimitBurst: 5
      onDemandAsk: http://:9765/healthz
  loadBalancer:
    externalTrafficPolicy: "Local"
    annotations:
      service.beta.kubernetes.io/do-loadbalancer-protocol: "http"
      service.beta.kubernetes.io/do-loadbalancer-algorithm: "round_robin"
      service.beta.kubernetes.io/do-loadbalancer-tls-ports: "443"
      service.beta.kubernetes.io/do-loadbalancer-tls-passthrough: "true"
      service.beta.kubernetes.io/do-loadbalancer-redirect-http-to-https: "true"
      service.beta.kubernetes.io/do-loadbalancer-enable-proxy-protocol: "true"
```


## Parameters

### Global parameters

| Name                                                               | Description                                                                             | Value                   |
| ------------------------------------------------------------------ | --------------------------------------------------------------------------------------- | ----------------------- |
| `global.quopit.imageRegistry`                                     | Global Docker image registry                                                            | `quopit`               |
| `global.quopit.imagePullSecrets`                                  | Global Docker registry secret names as an array                                         | `[]`                    |
| `global.quopit.image.tag`                                         | Global Docker image tag                                                                 | `2.2.2`                |
| `global.quopit.serviceAccount.shared`                             | Set to true to share the service account between all application components.            | `true`                  |
| `global.quopit.serviceAccount.create`                             | Set to true to create a service account to share between all application components.    | `true`                  |
| `global.quopit.serviceAccount.name`                               | Configure a name for service account to share between all application components.       | `quopit`               |
| `global.quopit.serviceAccount.annotations`                        | Configure annotations for the shared service account.                                   | `{}`                    |
| `global.quopit.serviceAccount.automountServiceAccountToken`       | Automount the service account token to the pods.                                        | `false`                 |
| `global.quopit.backendConfigMap`                                  | Configure a name for the backend configmap.                                             | `backend-config`        |
| `global.quopit.backendSecret`                                     | Configure a name for the backend secret.                                                | `backend-secret`        |
| `global.quopit.frontendConfigMap`                                 | Configure a name for the frontend configmap.                                            | `frontend-config`       |
| `global.quopit.sharedConfigMap`                                   | Configure a name for the shared configmap.                                              | `shared-config`         |
| `global.quopit.envFrom`                                           | Configure secrets or configMaps to be used as environment variables for all components. | `[]`                    |
| `global.quopit.domain`                                            | Configure the domain for the frontend application.                                      | `cluster.local`         |
| `global.quopit.backendDomain`                                     | Configure the domain for the backend application.                                       | `api.cluster.local`     |
| `global.quopit.objectsDomain`                                     | Configure the domain for the external facing minio api.                                 | `objects.cluster.local` |
| `global.quopit.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                    | `false`                 |
| `global.quopit.containerSecurityContext.seLinuxOptions`           | Set SELinux options in container                                                        | `{}`                    |
| `global.quopit.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                              | `""`                    |
| `global.quopit.containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup                                             | `""`                    |
| `global.quopit.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                           | `""`                    |
| `global.quopit.containerSecurityContext.privileged`               | Set container's Security Context privileged                                             | `false`                 |
| `global.quopit.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                 | `false`                 |
| `global.quopit.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                               | `false`                 |
| `global.quopit.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                      | `[]`                    |
| `global.quopit.containerSecurityContext.capabilities.add`         | List of capabilities to be added                                                        | `[]`                    |
| `global.quopit.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                        | `""`                    |
| `global.quopit.securityContext.enabled`                           | Enable security context                                                                 | `false`                 |
| `global.quopit.securityContext.fsGroupChangePolicy`               | Set filesystem group change policy                                                      | `Always`                |
| `global.quopit.securityContext.sysctls`                           | Set kernel settings using the sysctl interface                                          | `[]`                    |
| `global.quopit.securityContext.supplementalGroups`                | Set filesystem extra groups                                                             | `[]`                    |
| `global.quopit.securityContext.fsGroup`                           | Group ID for the pod                                                                    | `""`                    |

### Quopit Configuration

| Name                | Description               | Value  |
| ------------------- | ------------------------- | ------ |
| `generateJwtSecret` | Generate a new JWT secret | `true` |

### Shared ConfigMap Configuration

| Name              | Description                                                       | Value |
| ----------------- | ----------------------------------------------------------------- | ----- |
| `sharedConfigMap` | Additional configuration for the shared ConfigMap, key value map. | `{}`  |

### Frontend ConfigMap Configuration

| Name                                      | Description                          | Value |
| ----------------------------------------- | ------------------------------------ | ----- |
| `frontendConfigMap.DOWNLOAD_FILE_VIA_XHR` | Set to "1" to download files via XHR | `1`   |

### backend Secrets Configuration

| Name             | Description                                                      | Value |
| ---------------- | ---------------------------------------------------------------- | ----- |
| `backendSecrets` | Additional configuration for the backend Secrets, key value map. | `{}`  |

### backend ConfigMap Configuration

| Name                                                              | Description                                                | Value   |
| ----------------------------------------------------------------- | ---------------------------------------------------------- | ------- |
| `backendConfigMap.DONT_UPDATE_FORMULAS_AFTER_MIGRATION`           | Set to "yes" to disable updating formulas after migration  | `yes`   |
| `backendConfigMap.SYNC_TEMPLATES_ON_STARTUP`                      | Set to "false" to disable syncing templates on startup     | `false` |
| `backendConfigMap.MIGRATE_ON_STARTUP`                             | Set to "false" to disable migration on startup             | `false` |
| `backendConfigMap.QUOPIT_TRIGGER_SYNC_TEMPLATES_AFTER_MIGRATION` | Set to "true" to trigger syncing templates after migration | `true`  |

### Migration Job Configuration

| Name                                                          | Description                                               | Value     |
| ------------------------------------------------------------- | --------------------------------------------------------- | --------- |
| `migration.enabled`                                           | Enabled the migration job                                 | `true`    |
| `migration.image.repository`                                  | Migration job Docker image repository                     | `backend` |
| `migration.priorityClassName`                                 | Kubernetes priority class name for the migration job      | `""`      |
| `migration.nodeSelector`                                      | Node labels for pod assignment                            | `{}`      |
| `migration.tolerations`                                       | Tolerations for pod assignment                            | `[]`      |
| `migration.affinity`                                          | Affinity settings for pod assignment                      | `[]`      |
| `migration.extraEnv`                                          | Extra environment variables for the migration job         | `[]`      |
| `migration.envFrom`                                           | ConfigMaps or Secrets to be used as environment variables | `[]`      |
| `migration.volumes`                                           | Volumes for the migration job                             | `[]`      |
| `migration.volumeMounts`                                      | Volume mounts for the migration job                       | `[]`      |
| `migration.securityContext.enabled`                           | Enable security context                                   | `false`   |
| `migration.securityContext.fsGroupChangePolicy`               | Set filesystem group change policy                        | `""`      |
| `migration.securityContext.sysctls`                           | Set kernel settings using the sysctl interface            | `""`      |
| `migration.securityContext.supplementalGroups`                | Set filesystem extra groups                               | `""`      |
| `migration.securityContext.fsGroup`                           | Group ID for the pod                                      | `""`      |
| `migration.containerSecurityContext.enabled`                  | Enabled containers' Security Context                      | `false`   |
| `migration.containerSecurityContext.seLinuxOptions`           | Set SELinux options in container                          | `{}`      |
| `migration.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                | `""`      |
| `migration.containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup               | `""`      |
| `migration.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot             | `""`      |
| `migration.containerSecurityContext.privileged`               | Set container's Security Context privileged               | `false`   |
| `migration.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem   | `false`   |
| `migration.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation | `false`   |
| `migration.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                        | `[]`      |
| `migration.containerSecurityContext.capabilities.add`         | List of capabilities to be added                          | `[]`      |
| `migration.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile          | `""`      |

### Quopit Backend ASGI Configuration

| Name                                                                 | Description                                                                                  | Value                                                                                   |
| -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| `quopit-backend-asgi.image.repository`                              | Docker image repository for the ASGI server.                                                 | `backend`                                                                               |
| `quopit-backend-asgi.args`                                          | Arguments passed to the ASGI server.                                                         | `["gunicorn"]`                                                                          |
| `quopit-backend-asgi.livenessProbe.exec.command`                    | The command used to check the liveness of the ASGI server.                                   | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh backend-healthcheck"]` |
| `quopit-backend-asgi.livenessProbe.failureThreshold`                | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                     |
| `quopit-backend-asgi.livenessProbe.initialDelaySeconds`             | Delay before the liveness probe is initiated after the container starts.                     | `120`                                                                                   |
| `quopit-backend-asgi.livenessProbe.periodSeconds`                   | How often (in seconds) to perform the probe.                                                 | `30`                                                                                    |
| `quopit-backend-asgi.livenessProbe.successThreshold`                | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                     |
| `quopit-backend-asgi.livenessProbe.timeoutSeconds`                  | Number of seconds after which the probe times out.                                           | `5`                                                                                     |
| `quopit-backend-asgi.readinessProbe.exec.command`                   | The command used to check the readiness of the ASGI server.                                  | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh backend-healthcheck"]` |
| `quopit-backend-asgi.readinessProbe.failureThreshold`               | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                     |
| `quopit-backend-asgi.readinessProbe.initialDelaySeconds`            | Delay before the readiness probe is initiated after the container starts.                    | `120`                                                                                   |
| `quopit-backend-asgi.readinessProbe.periodSeconds`                  | How often (in seconds) to perform the probe.                                                 | `30`                                                                                    |
| `quopit-backend-asgi.readinessProbe.successThreshold`               | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                     |
| `quopit-backend-asgi.readinessProbe.timeoutSeconds`                 | Number of seconds after which the probe times out.                                           | `5`                                                                                     |
| `quopit-backend-asgi.autoscaling.enabled`                           | Enable autoscaling                                                                           | `false`                                                                                 |
| `quopit-backend-asgi.autoscaling.minReplicas`                       | Minimum number of replicas                                                                   | `2`                                                                                     |
| `quopit-backend-asgi.autoscaling.maxReplicas`                       | Maximum number of replicas                                                                   | `10`                                                                                    |
| `quopit-backend-asgi.autoscaling.targetCPUUtilizationPercentage`    | Target CPU utilization percentage for autoscaling                                            | `80`                                                                                    |
| `quopit-backend-asgi.autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage for autoscaling                                         | `80`                                                                                    |

### Quopit Backend WSGI Configuration

| Name                                                                 | Description                                                                                  | Value                                                                                   |
| -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| `quopit-backend-wsgi.image.repository`                              | Docker image repository for the WSGI server.                                                 | `backend`                                                                               |
| `quopit-backend-wsgi.args`                                          | Arguments passed to the WSGI server.                                                         | `["gunicorn-wsgi","--timeout","120"]`                                                   |
| `quopit-backend-wsgi.livenessProbe.exec.command`                    | The command used to check the liveness of the WSGI server.                                   | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh backend-healthcheck"]` |
| `quopit-backend-wsgi.livenessProbe.failureThreshold`                | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                     |
| `quopit-backend-wsgi.livenessProbe.initialDelaySeconds`             | Delay before the liveness probe is initiated after the container starts.                     | `120`                                                                                   |
| `quopit-backend-wsgi.livenessProbe.periodSeconds`                   | How often (in seconds) to perform the probe.                                                 | `30`                                                                                    |
| `quopit-backend-wsgi.livenessProbe.successThreshold`                | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                     |
| `quopit-backend-wsgi.livenessProbe.timeoutSeconds`                  | Number of seconds after which the probe times out.                                           | `5`                                                                                     |
| `quopit-backend-wsgi.readinessProbe.exec.command`                   | The command used to check the readiness of the wsgi server.                                  | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh backend-healthcheck"]` |
| `quopit-backend-wsgi.readinessProbe.failureThreshold`               | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                     |
| `quopit-backend-wsgi.readinessProbe.initialDelaySeconds`            | Delay before the readiness probe is initiated after the container starts.                    | `120`                                                                                   |
| `quopit-backend-wsgi.readinessProbe.periodSeconds`                  | How often (in seconds) to perform the probe.                                                 | `30`                                                                                    |
| `quopit-backend-wsgi.readinessProbe.successThreshold`               | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                     |
| `quopit-backend-wsgi.readinessProbe.timeoutSeconds`                 | Number of seconds after which the probe times out.                                           | `5`                                                                                     |
| `quopit-backend-wsgi.autoscaling.enabled`                           | Enable autoscaling                                                                           | `false`                                                                                 |
| `quopit-backend-wsgi.autoscaling.minReplicas`                       | Minimum number of replicas                                                                   | `2`                                                                                     |
| `quopit-backend-wsgi.autoscaling.maxReplicas`                       | Maximum number of replicas                                                                   | `10`                                                                                    |
| `quopit-backend-wsgi.autoscaling.targetCPUUtilizationPercentage`    | Target CPU utilization percentage for autoscaling                                            | `80`                                                                                    |
| `quopit-backend-wsgi.autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage for autoscaling                                         | `80`                                                                                    |

### Quopit Web Frontend Configuration

| Name                                                             | Description                                                                                  | Value          |
| ---------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | -------------- |
| `quopit-frontend.image.repository`                              | Docker image repository for the Web Frontend server.                                         | `web-frontend` |
| `quopit-frontend.args`                                          | Arguments passed to the Web Frontend server.                                                 | `["nuxt"]`     |
| `quopit-frontend.workingDir`                                    | Working Directory for the container.                                                         | `""`           |
| `quopit-frontend.livenessProbe.httpGet.path`                    | The path to check for the liveness probe.                                                    | `/_health`     |
| `quopit-frontend.livenessProbe.httpGet.port`                    | The port to check for the liveness probe.                                                    | `3000`         |
| `quopit-frontend.livenessProbe.httpGet.scheme`                  | The scheme to use for the liveness probe.                                                    | `HTTP`         |
| `quopit-frontend.livenessProbe.failureThreshold`                | Number of times the probe can fail before the container is restarted.                        | `3`            |
| `quopit-frontend.livenessProbe.initialDelaySeconds`             | Delay before the liveness probe is initiated after the container starts.                     | `5`            |
| `quopit-frontend.livenessProbe.periodSeconds`                   | How often (in seconds) to perform the probe.                                                 | `30`           |
| `quopit-frontend.livenessProbe.successThreshold`                | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`            |
| `quopit-frontend.livenessProbe.timeoutSeconds`                  | Number of seconds after which the probe times out.                                           | `5`            |
| `quopit-frontend.readinessProbe.httpGet.path`                   | The path to check for the readiness probe.                                                   | `/_health`     |
| `quopit-frontend.readinessProbe.httpGet.port`                   | The port to check for the readiness probe.                                                   | `3000`         |
| `quopit-frontend.readinessProbe.httpGet.scheme`                 | The scheme to use for the readiness probe.                                                   | `HTTP`         |
| `quopit-frontend.readinessProbe.failureThreshold`               | Number of times the probe can fail before the container is restarted.                        | `3`            |
| `quopit-frontend.readinessProbe.initialDelaySeconds`            | Delay before the readiness probe is initiated after the container starts.                    | `5`            |
| `quopit-frontend.readinessProbe.periodSeconds`                  | How often (in seconds) to perform the probe.                                                 | `30`           |
| `quopit-frontend.readinessProbe.successThreshold`               | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`            |
| `quopit-frontend.readinessProbe.timeoutSeconds`                 | Number of seconds after which the probe times out.                                           | `5`            |
| `quopit-frontend.mountConfiguration.backend`                    | If enabled, all the backend service configurations and secrets will be mounted.              | `false`        |
| `quopit-frontend.mountConfiguration.frontend`                   | If enabled, all the frontend service configurations and secrets will be mounted.             | `true`         |
| `quopit-frontend.service.targetPort`                            | The port the Web Frontend server listens on.                                                 | `3000`         |
| `quopit-frontend.autoscaling.enabled`                           | Enable autoscaling                                                                           | `false`        |
| `quopit-frontend.autoscaling.minReplicas`                       | Minimum number of replicas                                                                   | `2`            |
| `quopit-frontend.autoscaling.maxReplicas`                       | Maximum number of replicas                                                                   | `10`           |
| `quopit-frontend.autoscaling.targetCPUUtilizationPercentage`    | Target CPU utilization percentage for autoscaling                                            | `80`           |
| `quopit-frontend.autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage for autoscaling                                         | `80`           |

### Quopit Celery beat Configuration

| Name                                          | Description                                                            | Value             |
| --------------------------------------------- | ---------------------------------------------------------------------- | ----------------- |
| `quopit-celery-beat-worker.image.repository` | Docker image repository for the Celery beat worker.                    | `backend`         |
| `quopit-celery-beat-worker.args`             | Arguments passed to the Celery beat worker.                            | `["celery-beat"]` |
| `quopit-celery-beat-worker.replicaCount`     | Number of replicas for the Celery beat worker.                         | `1`               |
| `quopit-celery-beat-worker.service.create`   | Set to false to disable creating a service for the Celery beat worker. | `false`           |

### Quopit Celery export worker Configuration

| Name                                            | Description                                                            | Value                     |
| ----------------------------------------------- | ---------------------------------------------------------------------- | ------------------------- |
| `quopit-celery-export-worker.image.repository` | Docker image repository for the Celery export worker.                  | `backend`                 |
| `quopit-celery-export-worker.args`             | Arguments passed to the Celery export worker.                          | `["celery-exportworker"]` |
| `quopit-celery-export-worker.replicaCount`     | Number of replicas for the Celery export worker.                       | `1`                       |
| `quopit-celery-export-worker.service.create`   | Set to false to disable creating a service for the Celery beat worker. | `false`                   |

### Quopit Celery worker Configuration

| Name                                                       | Description                                                                                  | Value                                                                                         |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `quopit-celery-worker.image.repository`                   | Docker image repository for the Celery worker.                                               | `backend`                                                                                     |
| `quopit-celery-worker.args`                               | Arguments passed to the Celery worker.                                                       | `["celery-worker"]`                                                                           |
| `quopit-celery-worker.replicaCount`                       | Number of replicas for the Celery worker.                                                    | `1`                                                                                           |
| `quopit-celery-worker.service.create`                     | Set to false to disable creating a service for the Celery beat worker.                       | `false`                                                                                       |
| `quopit-celery-worker.livenessProbe.exec.command`         | The command used to check the liveness of the WSGI server.                                   | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh celery-worker-healthcheck"]` |
| `quopit-celery-worker.livenessProbe.failureThreshold`     | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                           |
| `quopit-celery-worker.livenessProbe.initialDelaySeconds`  | Delay before the liveness probe is initiated after the container starts.                     | `10`                                                                                          |
| `quopit-celery-worker.livenessProbe.periodSeconds`        | How often (in seconds) to perform the probe.                                                 | `30`                                                                                          |
| `quopit-celery-worker.livenessProbe.successThreshold`     | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                           |
| `quopit-celery-worker.livenessProbe.timeoutSeconds`       | Number of seconds after which the probe times out.                                           | `10`                                                                                          |
| `quopit-celery-worker.readinessProbe.exec.command`        | The command used to check the readiness of the wsgi server.                                  | `["/bin/bash","-c","/quopit/backend/docker/docker-entrypoint.sh celery-worker-healthcheck"]` |
| `quopit-celery-worker.readinessProbe.failureThreshold`    | Number of times the probe can fail before the container is restarted.                        | `3`                                                                                           |
| `quopit-celery-worker.readinessProbe.initialDelaySeconds` | Delay before the readiness probe is initiated after the container starts.                    | `10`                                                                                          |
| `quopit-celery-worker.readinessProbe.periodSeconds`       | How often (in seconds) to perform the probe.                                                 | `30`                                                                                          |
| `quopit-celery-worker.readinessProbe.successThreshold`    | Minimum consecutive successes for the probe to be considered successful after having failed. | `1`                                                                                           |
| `quopit-celery-worker.readinessProbe.timeoutSeconds`      | Number of seconds after which the probe times out.                                           | `10`                                                                                          |

### Quopit Celery Flower Configuration

| Name                                     | Description                                                    | Value               |
| ---------------------------------------- | -------------------------------------------------------------- | ------------------- |
| `quopit-celery-flower.enabled`          | Set to true to enable the Celery Flower monitoring tool.       | `false`             |
| `quopit-celery-flower.image.repository` | Docker image repository for the Celery Flower monitoring tool. | `backend`           |
| `quopit-celery-flower.args`             | Arguments passed to the Celery Flower monitoring tool.         | `["celery-flower"]` |
| `quopit-celery-flower.replicaCount`     | Number of replicas for the Celery Flower monitoring tool.      | `1`                 |

### Quopit Embeddings Configuration

| Name                                                            | Description                                                     | Value                      |
| --------------------------------------------------------------- | --------------------------------------------------------------- | -------------------------- |
| `quopit-embeddings.enabled`                                    | Set to true to enable the Quopit Embeddings service.           | `false`                    |
| `quopit-embeddings.assistantLLMModel`                          | The LLM model to use for the Embeddings service.                | `groq/openai/gpt-oss-120b` |
| `quopit-embeddings.image.repository`                           | Docker image repository for the Embeddings service.             | `embeddings`               |
| `quopit-embeddings.resources`                                  | Resource requests and limits for the Embeddings service.        |                            |
| `quopit-embeddings.autoscaling.enabled`                        | Enable autoscaling for the Embeddings service.                  | `false`                    |
| `quopit-embeddings.autoscaling.minReplicas`                    | Minimum number of replicas for autoscaling.                     | `1`                        |
| `quopit-embeddings.autoscaling.maxReplicas`                    | Maximum number of replicas for autoscaling.                     | `3`                        |
| `quopit-embeddings.autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage for autoscaling.              | `80`                       |
| `quopit-embeddings.service.port`                               | Service port for the Embeddings service.                        | `80`                       |
| `quopit-embeddings.service.targetPort`                         | Target port for the Embeddings service.                         | `80`                       |
| `quopit-embeddings.readinessProbe.initialDelaySeconds`         | Initial delay for readiness probe.                              | `10`                       |
| `quopit-embeddings.readinessProbe.periodSeconds`               | Period for readiness probe.                                     | `10`                       |
| `quopit-embeddings.readinessProbe.timeoutSeconds`              | Timeout for readiness probe.                                    | `5`                        |
| `quopit-embeddings.livenessProbe.initialDelaySeconds`          | Initial delay for liveness probe.                               | `10`                       |
| `quopit-embeddings.livenessProbe.periodSeconds`                | Period for liveness probe.                                      | `10`                       |
| `quopit-embeddings.livenessProbe.timeoutSeconds`               | Timeout for liveness probe.                                     | `5`                        |
| `quopit-embeddings.pdb.create`                                 | Enable/disable a Pod Disruption Budget creation.                | `false`                    |
| `quopit-embeddings.pdb.minAvailable`                           | Minimum number/percentage of pods that should remain scheduled. | `75%`                      |

### Ingress Configuration

| Name                                              | Description                                | Value                                     |
| ------------------------------------------------- | ------------------------------------------ | ----------------------------------------- |
| `ingress.enabled`                                 | Enable the Ingress resource                | `true`                                    |
| `ingress.annotations.kubernetes.io/ingress.class` | Ingress class annotation                   | `{"kubernetes.io/ingress.class":"caddy"}` |
| `ingress.tls`                                     | TLS configuration for the Ingress resource | `[]`                                      |

### Redis Configuration

| Name                        | Description                                                     | Value        |
| --------------------------- | --------------------------------------------------------------- | ------------ |
| `redis.enabled`             | Enable the Redis database                                       | `true`       |
| `redis.architecture`        | The Redis architecture                                          | `standalone` |
| `redis.auth.enabled`        | Enable Redis authentication                                     | `true`       |
| `redis.auth.password`       | The password for the Redis database                             | `quopit`    |
| `redis.auth.existingSecret` | The name of an existing secret containing the database password | `""`         |

### PostgreSQL Configuration

| Name                             | Description                                                     | Value     |
| -------------------------------- | --------------------------------------------------------------- | --------- |
| `postgresql.enabled`             | Enable the PostgreSQL database                                  | `true`    |
| `postgresql.auth.database`       | The name of the database                                        | `quopit` |
| `postgresql.auth.existingSecret` | The name of an existing secret containing the database password | `""`      |
| `postgresql.auth.password`       | The password for the database                                   | `quopit` |
| `postgresql.auth.username`       | The username for the database                                   | `quopit` |

### Minio Configuration

| Name                                 | Description                                      | Value                                            |
| ------------------------------------ | ------------------------------------------------ | ------------------------------------------------ |
| `minio.enabled`                      | Enable the Minio object storage service          | `true`                                           |
| `minio.networkPolicy.enabled`        | Enable the Minio network policy                  | `false`                                          |
| `minio.disableWebUI`                 | Disable the Minio web UI                         | `true`                                           |
| `minio.provisioning.enabled`         | Enable the Minio provisioning service            | `true`                                           |
| `minio.provisioning.buckets[0].name` | Name of the bucket to create                     | `quopit`                                        |
| `minio.provisioning.extraCommands`   | List of extra commands to run after provisioning | `mc anonymous set download provisioning/quopit` |

### Caddy Configuration

| Name                                                   | Description                                                          | Value                  |
| ------------------------------------------------------ | -------------------------------------------------------------------- | ---------------------- |
| `caddy.enabled`                                        | Enable the Caddy ingress controller                                  | `true`                 |
| `caddy.ingressController.className`                    | Ingress class name which caddy will look for on ingress annotations. | `caddy`                |
| `caddy.ingressController.config.email`                 | Email address to use for Let's Encrypt certificates                  | `my@email.com`         |
| `caddy.ingressController.config.proxyProtocol`         | Enable the PROXY protocol                                            | `true`                 |
| `caddy.ingressController.config.experimentalSmartSort` | Enable experimental smart sorting                                    | `false`                |
| `caddy.ingressController.config.onDemandTLS`           | Enable on-demand TLS                                                 | `true`                 |
| `caddy.ingressController.config.onDemandAsk`           | URL to check for on-demand TLS                                       | `http://:9765/healthz` |
| `caddy.loadBalancer.externalTrafficPolicy`             | External traffic policy for the load balancer                        | `Local`                |
| `caddy.loadBalancer.annotations`                       | Annotations for the load balancer                                    | `{}`                   |
